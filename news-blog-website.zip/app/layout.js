export const metadata = {
  title: 'Daily India News',
  description: 'Live breaking Indian news blog',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}