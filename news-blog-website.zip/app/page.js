'use client';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Moon, Sun } from 'lucide-react';

const categories = ['All', 'Technology', 'Sports', 'Politics'];

export default function Page() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [articles, setArticles] = useState([]);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    fetchArticles();
  }, []);

  const fetchArticles = async () => {
    try {
      const res = await axios.get('https://newsapi.org/v2/top-headlines?country=in&apiKey=YOUR_API_KEY');
      const formatted = res.data.articles.map((a, i) => ({
        id: i,
        title: a.title,
        summary: a.description,
        image: a.urlToImage,
        category: 'General'
      }));
      setArticles(formatted);
    } catch (err) {
      console.error('News fetch failed', err);
    }
  };

  const filtered = selectedCategory === 'All' ? articles : articles.filter(a => a.category === selectedCategory);

  return (
    <div className={darkMode ? 'dark bg-gray-900 text-white min-h-screen p-6' : 'bg-white text-black min-h-screen p-6'}>
      <div className='max-w-7xl mx-auto'>
        <div className='flex justify-between items-center mb-6'>
          <h1 className='text-4xl font-bold'>🗞️ Daily India News</h1>
          <button onClick={() => setDarkMode(!darkMode)}>{darkMode ? <Sun /> : <Moon />}</button>
        </div>
        <div className='flex flex-wrap justify-center gap-3 mb-6'>
          {categories.map(cat => (
            <button key={cat} onClick={() => setSelectedCategory(cat)} className='border rounded px-3 py-1'>
              {cat}
            </button>
          ))}
        </div>
        <div className='grid sm:grid-cols-2 lg:grid-cols-3 gap-6'>
          {filtered.map(article => (
            <div key={article.id} className='bg-white dark:bg-gray-800 shadow-md rounded overflow-hidden'>
              <img src={article.image || 'https://source.unsplash.com/600x400/?news'} alt={article.title} className='w-full h-48 object-cover' />
              <div className='p-4'>
                <h2 className='text-xl font-semibold mb-2'>{article.title}</h2>
                <p className='text-sm mb-2'>{article.summary}</p>
                <span className='text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded'>{article.category}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}